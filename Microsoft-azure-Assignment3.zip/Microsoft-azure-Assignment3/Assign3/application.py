from flask import Flask,render_template,request
import sys,os
import pyodbc
import pypyodbc
import memcache
import time
import pandas as pd
import random
import urllib
import datetime
import json
import redis
import pickle
import hashlib

app = Flask(__name__)

server = ''
database = ''
username = ''
password = ''
driver = '{ODBC Driver 17 for SQL Server}'
myHostname = ""
myPassword = ""
# Enter Server, host and password. Deleted for security purposes

#r = redis.StrictRedis(host=myHostname, port=6380, password=myPassword, ssl=True)

pool = redis.ConnectionPool(host=myHostname,
port=6380,
password=myPassword,
db=0,
connection_class=redis.SSLConnection,
ssl_cert_reqs=u'none')
r = redis.Redis(connection_pool=pool)


#ssl_cert_reqs=u'none'
#r = redis.Redis(host=myHostname, port=6380, db=0, password=myPassword, ssl=True)
#r = redis.StrictRedis(host='', port=6379, db=0, password= myPassword, ssl=True)
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=;DATABASE=;UID=;PWD=')
cursor = cnxn.cursor()

@app.route('/')
def index():
    return render_template('home.html')


# @app.route("/displayDB", methods=["POST"])
# def displayDB():
#     query1 = "SELECT TIME, LATITUDE, LONGITUDE from QUAKES LIMIT 5"
#     cursor.execute(query1)
#     rows = cursor.fetchall()
#     return render_template('displayDB.html', rows=rows)

@app.route('/displayDB',methods=["POST"])
def displayDB():
    if request.method=='POST':
         cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=;DATABASE=;UID=;PWD=')
         cursor = cnxn.cursor()
         query1=("SELECT TOP 5 TIME, LATITUDE, LONGITUDE from QUAKES ;")
         cursor.execute(query1)
         rows = cursor.fetchall();
         return render_template("displayDB.html",rows=rows)

@app.route('/rand',methods=["POST"])
def rand():
    if request.method=='POST':
         cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=;DATABASE=;UID=;PWD=')
         cursor = cnxn.cursor()
         num = int(request.form['num'])
         start_time = time.time()
         for i in range(0, num):
             mag = random.uniform(0.5, 6.5)
             mag = str("{0:.2f}".format(mag))
             query1 = ("SELECT * from QUAKES WHERE MAG =" + mag )
             cursor.execute(query1)
         end_time = time.time()
         time_diff = end_time - start_time
         return render_template("rand.html",time=time_diff, num=num)

@app.route('/restrand',methods=["POST"])
def restrand():
    if request.method=='POST':
         cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=;DATABASE=;UID=;PWD=')
         cursor = cnxn.cursor()
         num = int(request.form['num'])
         start_time = time.time()
         for i in range(0, num):
             mag = random.uniform(0.5, 6.5)
             mag = float("{0:.2f}".format(mag))
             query1 = ("select * from QUAKES where MAG =" + str(mag) + " and GAP between 50 and 100")
             cursor.execute(query1)
         end_time = time.time()
         time_diff = end_time - start_time
         return render_template("rand.html",time=time_diff, num=num)

def randrange(rangfro=None,rangto=None,num=None):
    cnxn = pypyodbc.connect( 'DRIVER=' + driver + ';SERVER=' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
    cursor = cnxn.cursor()
    start = time.time()
    for i in range(0,int(num)):
        mag= round(random.uniform(rangfro, rangto),2)
        success="SELECT * from [QUAKES] where MAG>'"+str(mag)+"'"
        hash = hashlib.sha224(success.encode('utf-8')).hexdigest()
        key = "redis_cache:" + hash
        if (r.get(key)):
           print("redis cached")
        else:
           # Do MySQL query
           cursor.execute(success)
           data = cursor.fetchall()
           rows = []
           for j in data:
                rows.append(str(j))
           # Put data into cache for 1 hour
           r.set(key, pickle.dumps(list(rows)) )
           r.expire(key, 36);
        cursor.execute(success)
    end = time.time()
    exectime = end - start
    return render_template('count.html', t=exectime)

@app.route('/multiplerun', methods=['GET'])
def randquery():
    rangfro = float(request.args.get('rangefrom'))
    rangto = float(request.args.get('rangeto'))
    num = request.args.get('nom')
    return randrange(rangfro,rangto,num)

port = os.getenv('PORT', '8080')
if __name__ == '__main__':
    app.debug = True
    app.run(host='0.0.0.0', port=int(port))

